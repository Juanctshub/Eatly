import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { mealType, availableFoods, restrictions } = body;

    if (!mealType || !availableFoods || !restrictions) {
      return NextResponse.json({ error: 'Faltan datos requeridos' }, { status: 400 });
    }

    // Crear el prompt para la IA
    const restrictionsList = restrictions.map((r: { foodItem: string; reason: string }) =>
      `- ${r.foodItem} (${r.reason})`
    ).join('\n');

    const foodsList = availableFoods.map((f: { name: string }) => f.name).join(', ');

    const prompt = `Eres un nutricionista experto que ayuda a personas con restricciones alimentarias.

El usuario tiene las siguientes restricciones alimentarias:
${restrictionsList}

Tipo de comida: ${mealType}

Alimentos disponibles: ${foodsList}

Por favor, genera 3-5 sugerencias de combinaciones de comidas que el usuario puede preparar con los alimentos disponibles, considerando sus restricciones.

Para cada sugerencia incluye:
1. Nombre del plato
2. Ingredientes a usar
3. Por qué es seguro para el usuario (considerando sus restricciones)
4. Beneficios nutricionales

Responde en formato JSON con esta estructura:
{
  "suggestions": [
    {
      "name": "Nombre del plato",
      "ingredients": ["ingrediente1", "ingrediente2"],
      "safetyReason": "Explicación de por qué es seguro",
      "nutritionalBenefits": "Beneficios nutricionales"
    }
  ],
  "generalTip": "Un consejo general para esta comida"
}

Responde SOLO con el JSON, sin texto adicional.`;

    // Llamar a la IA
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Eres un nutricionista experto en dietas especiales y restricciones alimentarias. Responde siempre en español y en formato JSON válido.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    const aiResponse = completion.choices[0]?.message?.content || '';

    // Parsear la respuesta JSON
    let suggestions;
    try {
      // Limpiar la respuesta si viene con markdown
      const cleanResponse = aiResponse.replace(/```json\n?|\n?```/g, '').trim();
      suggestions = JSON.parse(cleanResponse);
    } catch {
      // Si no se puede parsear, crear una estructura por defecto
      suggestions = {
        suggestions: [
          {
            name: 'Sugerencia personalizada',
            ingredients: availableFoods.map((f: { name: string }) => f.name).slice(0, 3),
            safetyReason: 'Combinación basada en tus alimentos disponibles y restricciones',
            nutritionalBenefits: 'Nutrientes equilibrados para tu comida'
          }
        ],
        generalTip: 'Consulta siempre con un profesional de la salud sobre tus restricciones alimentarias.'
      };
    }

    // Guardar la sugerencia en la base de datos
    await db.mealSuggestion.create({
      data: {
        mealType,
        suggestion: JSON.stringify(suggestions),
        explanation: suggestions.generalTip,
        compatibleFoods: JSON.stringify(availableFoods)
      }
    });

    return NextResponse.json(suggestions);
  } catch (error) {
    console.error('Error generating suggestions:', error);
    return NextResponse.json({ error: 'Error al generar sugerencias' }, { status: 500 });
  }
}

// GET - Obtener historial de sugerencias
export async function GET() {
  try {
    const suggestions = await db.mealSuggestion.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10
    });
    return NextResponse.json(suggestions);
  } catch (error) {
    console.error('Error fetching suggestions:', error);
    return NextResponse.json({ error: 'Error al obtener sugerencias' }, { status: 500 });
  }
}
