import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Obtener todos los alimentos disponibles
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const mealType = searchParams.get('mealType');

    const where = mealType ? { mealType } : {};

    const foods = await db.availableFood.findMany({
      where,
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(foods);
  } catch (error) {
    console.error('Error fetching foods:', error);
    return NextResponse.json({ error: 'Error al obtener alimentos' }, { status: 500 });
  }
}

// POST - Agregar alimento disponible
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, category, mealType } = body;

    if (!name) {
      return NextResponse.json({ error: 'Nombre del alimento es requerido' }, { status: 400 });
    }

    const food = await db.availableFood.create({
      data: {
        name,
        category,
        mealType
      }
    });

    return NextResponse.json(food);
  } catch (error) {
    console.error('Error creating food:', error);
    return NextResponse.json({ error: 'Error al agregar alimento' }, { status: 500 });
  }
}

// DELETE - Eliminar alimento
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID requerido' }, { status: 400 });
    }

    await db.availableFood.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting food:', error);
    return NextResponse.json({ error: 'Error al eliminar alimento' }, { status: 500 });
  }
}
