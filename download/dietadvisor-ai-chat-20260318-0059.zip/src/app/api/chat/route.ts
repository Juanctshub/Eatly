import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// Contexto del sistema para la IA
const SYSTEM_CONTEXT = `Eres un nutricionista experto y asistente de dietas especializado llamado "DietAdvisor". Tu rol es ayudar a personas con restricciones alimentarias a tomar decisiones seguras y saludables.

INSTRUCCIONES IMPORTANTES:
1. Siempre prioriza la SEGURIDAD del usuario - si un alimento podría ser peligroso, adviértelo claramente.
2. Sé específico con las recomendaciones - incluye nombres de platillos, ingredientes y preparaciones.
3. Cuando recomiendes recetas, incluye URLs de confianza como:
   - https://www.recetasgratis.net/buscar?q=[ingrediente]
   - https://cookpad.com/mx/buscar/[platillo]
   - https://www.kiwilimon.com/buscar?q=[platillo]
4. Formatea tus respuestas de forma clara con emojis y secciones.
5. Si el usuario pregunta qué NO puede comer, lista claramente los alimentos a evitar basándote en sus restricciones.
6. Si pregunta qué SÍ puede comer, da opciones deliciosas y seguras.
7. Usa la información de restricciones y alimentos disponibles que te proporcionan.
8. Sé amigable y empático - entiende que las restricciones pueden ser difíciles.

FORMATO DE RESPUESTA:
- Para recomendaciones de qué EVITAR: usa ⛔ y lista clara
- Para recomendaciones de qué COMER: usa ✅ con ideas específicas
- Para recetas: usa 📖 con el nombre y link
- Para tips nutricionales: usa 💡
- Para advertencias de seguridad: usa ⚠️

EJEMPLOS DE BUENAS RESPUESTAS:

Usuario: "¿Qué puedo cenar?"
Respuesta: "¡Claro! Para tu cena, aquí hay opciones seguras:

✅ **Opciones para ti:**
1. Ensalada Mediterránea - lechuga, tomate, pepino, aceitunas, queso feta, aceite de oliva
2. Salmón al horno con espárragos - rico en omega-3 y sin restricciones para ti
3. Sopa de verduras casera - reconfortante y nutritiva

📖 **Recetas:**
- https://www.kiwilimon.com/receta/sopas/sopa-de-verduras

💡 **Tip:** Cena temprano para mejor digestión."

RECUERDA: Tu objetivo es hacer que la alimentación con restricciones sea FÁCIL, SEGURA y DELICIOSA.`;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      message, 
      restrictions = [], 
      foods = [], 
      mealType = 'almuerzo',
      conversationHistory = []
    } = body;

    if (!message) {
      return NextResponse.json({ success: false, error: 'Mensaje requerido' }, { status: 400 });
    }

    const zai = await ZAI.create();

    // Construir contexto del usuario
    const userContext = `
INFORMACIÓN DEL USUARIO:
${restrictions.length > 0 
  ? `- Restricciones alimentarias: ${restrictions.map((r: any) => 
      `${r.foodItem} (motivo: ${r.reason || 'no especificado'}, severidad: ${r.severity || 'moderada'})`
    ).join('; ')}`
  : '- Sin restricciones registradas'}
${foods.length > 0 
  ? `- Alimentos disponibles: ${foods.map((f: any) => f.name).join(', ')}`
  : '- Sin alimentos registrados'}
- Tipo de comida actual: ${mealType}

IMPORTANTE: 
1. Si pregunta por algo que está en sus restricciones, adviértelo CLARAMente.
2. Sugiere SOLO alimentos que NO estén en sus restricciones.
3. Si no tiene restricciones, puedes sugerir cualquier cosa saludable.
`;

    // Construir historial de conversación para contexto
    const formattedHistory = conversationHistory.map((msg: any) => ({
      role: msg.role as 'user' | 'assistant',
      content: msg.content
    }));

    const messages = [
      { role: 'system', content: SYSTEM_CONTEXT + '\n\n' + userContext },
      ...formattedHistory,
      { role: 'user', content: message }
    ];

    const completion = await zai.chat.completions.create({
      messages,
      temperature: 0.7,
      max_tokens: 2000,
    });

    const responseContent = completion.choices[0]?.message?.content || 'Lo siento, no pude procesar tu solicitud. Por favor intenta de nuevo.';

    return NextResponse.json({
      success: true,
      response: responseContent,
      timestamp: new Date().toISOString()
    });

  } catch (error: any) {
    console.error('Error en chat IA:', error);
    return NextResponse.json({
      success: false,
      error: 'Error al procesar la solicitud. Intenta de nuevo.',
      details: error.message
    }, { status: 500 });
  }
}
