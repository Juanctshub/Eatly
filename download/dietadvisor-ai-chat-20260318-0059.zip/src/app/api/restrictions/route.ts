import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Obtener todas las restricciones
export async function GET() {
  try {
    const restrictions = await db.dietaryRestriction.findMany({
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(restrictions);
  } catch (error) {
    console.error('Error fetching restrictions:', error);
    return NextResponse.json({ error: 'Error al obtener restricciones' }, { status: 500 });
  }
}

// POST - Crear nueva restricción
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { foodItem, reason, severity, notes } = body;

    if (!foodItem || !reason) {
      return NextResponse.json({ error: 'Alimento y razón son requeridos' }, { status: 400 });
    }

    const restriction = await db.dietaryRestriction.create({
      data: {
        foodItem,
        reason,
        severity: severity || 'moderada',
        notes
      }
    });

    return NextResponse.json(restriction);
  } catch (error) {
    console.error('Error creating restriction:', error);
    return NextResponse.json({ error: 'Error al crear restricción' }, { status: 500 });
  }
}

// DELETE - Eliminar restricción
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID requerido' }, { status: 400 });
    }

    await db.dietaryRestriction.delete({
      where: { id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting restriction:', error);
    return NextResponse.json({ error: 'Error al eliminar restricción' }, { status: 500 });
  }
}
